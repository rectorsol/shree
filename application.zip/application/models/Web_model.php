<?php
class Web_model extends CI_Model {}
