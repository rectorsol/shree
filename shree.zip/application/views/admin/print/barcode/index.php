<?php include('layout/css.php'); ?>

    <?php echo $main_content; ?>

<?php include('layout/footer.php'); ?>
