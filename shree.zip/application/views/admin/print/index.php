<?php include('layout/css.php'); ?>
<a href="<?php echo $_SERVER['HTTP_REFERER'];  ?>" class="btn btn-primary" >Go Back</a>
  <div class=" PrintThis">
    <?php echo $main_content; ?>
  </div>
<?php include('layout/footer.php'); ?>
