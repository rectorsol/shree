<script type="text/javascript">
  $(document).ready(function() {

jQuery('#master').on('click', function(e) {
 if($(this).is(':checked',true))
 {
   $(".sub_chk").prop('checked', true);
 }
 else
 {
   $(".sub_chk").prop('checked',false);
 }
});


jQuery('.delete_all').on('click', function(e) {
var allVals = [];
   $(".sub_chk:checked").each(function() {
     allVals.push($(this).attr('data-id'));
   });
   //alert(allVals.length); return false;
   if(allVals.length <=0)
   {
     alert("Please select row.");
   }
   else {
     //$("#loading").show();
     WRN_PROFILE_DELETE = "Are you sure you want to delete this row?";
     var check = confirm(WRN_PROFILE_DELETE);
     if(check == true){
       //for server side
     var join_selected_values = allVals.join(",");
     // alert (join_selected_values);exit;

       $.ajax({
         type: "POST",
         url: "<?= base_url()?>admin/design/deleteUser",
         cache:false,
         data: {'ids' : join_selected_values, '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php  echo $this->security->get_csrf_hash(); ?>'},
         success: function(response)
         {

           //referesh table
           $(".sub_chk:checked").each(function() {
              var id = $(this).attr('data-id');
              $('#tr_'+id).remove();
           });


         }
       });
              //for client side

     }
   }
 });
 
 jQuery('.select_all').on('click', function(e) {
var allVals = [];
   $(".sub_chk:checked").each(function() {
     allVals.push($(this).attr('data-id'));
   });
   //alert(allVals.length); return false;
   if(allVals.length <=0)
   {
     alert("Please select row.");
   }
   else {
     //$("#loading").show();
     WRN_PROFILE_DELETE = "Are you sure you want to show this  row?";
     var check = confirm(WRN_PROFILE_DELETE);
     if(check == true){
       //for server side
     var join_selected_values = allVals.join(",");
     // alert (join_selected_values);exit;
      
       $.ajax({
         type: "POST",
         url: "<?= base_url()?>admin/design/get_data",
         cache:false,
         data: {'ids' : join_selected_values, '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php  echo $this->security->get_csrf_hash(); ?>'},
         success: function(response)
         {

           //referesh table
           //  $(".sub_chk:checked").each(function() {
           //    var id = $(this).attr('data-id');
           //    $('#tr_'+id).remove();
           // });


         }
       });
              //for client side

     }
   }
 });
 
 jQuery('.print_all').on('click', function(e) {
  var allVals = [];
   $(".sub_chk:checked").each(function() {
     allVals.push($(this).attr('data-id'));
   });
   //alert(allVals.length); return false;
   if(allVals.length <=0)
   {
     alert("Please select row.");
   }
   else {
     //$("#loading").show();
     WRN_PROFILE_DELETE = "Are you sure you want to Print this rows?";
     var check = confirm(WRN_PROFILE_DELETE);
     if(check == true){
       //for server side
     var join_selected_values = allVals.join(",");
     // alert (join_selected_values);exit;
     var ids = join_selected_values.split(",");
     var data = [];
     $.each(ids, function(index, value){
       if (value != "") {
         data[index] = value;
       }
     });
       $.ajax({
         type: "POST",
         url: "<?= base_url()?>admin/PrintThis/designmultiprint",
         cache:false,
         data: {'ids' : data, '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php  echo $this->security->get_csrf_hash(); ?>'},
         success: function(response)
         {
           $("body").html(response);
         }
       });
              //for client side

     }
   }
 });

$('#fabricName').on('change', function(){
   var 	fabricName =  $(this).val();
    $.ajax({
         type: "POST",
         url: "<?= base_url()?>admin/design/fabricOn",
         cache:false,
         data: {'fabricName' : 	fabricName, '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php  echo $this->security->get_csrf_hash(); ?>'},
         success: function(response)
         {
             $('#designOn').val(response);
         }
       });
});
  $("#design_name").on('focusout', function(){
       $("#design_name").css("border", "1px solid #DDDDDD");
       $("#design_btn").removeAttr("disabled", "TRUE");
       $("#design-error").html('');
       var designName = $(this).val();
    //   alert(design_name);
       $.ajax({
         type: "POST",
         url: "<?php echo base_url('admin/Design/designExist')?>",
         data: {'designName':designName, '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php  echo $this->security->get_csrf_hash(); ?>'},
         datatype: 'json',
         success: function(data){
           if(data == true){
              $("#design_name").css("border", "2px solid #F47C72");
              $("#design_btn").attr("disabled", "TRUE");
              $("#design-error").html('Design Name Already Exist.');
            }
         }
       });
     });

   });

   </script>
